/**
 * JavaScript to provide internet interface for the lab equipment
 *
 * Version 7.7.0
 * Dmytro Kosenkov and Nicole Famularo, Monmouth University
 * 
 * May 28, 2015
 * 
 * 
 **/

var _PASSWORD_ = "";  // string hCtr0  =  "";  // Hardware password
var _SESSION_ID_ = ""; // string hCtr1  =  "";  // Client's session ID key (timestamp)
var _CTR_KEY0_ = "ctr0"; //Password
var _CTR_KEY1_ = "ctr1"; //Session ID
var _CTR_KEY2_ = "ctr2"; //Action code
var _CTR_KEY3_ = "ctr3"; //Action value
var _AJAX_FILE_ = "ajax.htm";    
var _ACT_DRAIN_ = 1; // drain titrant
var _ACT_GO_ = 2; // dispense titrant
var _ACT_MEASURE_PH_V_ = 3; // Measure and report pH and volume
var _ACT_RESET_ = 4; //Reset volume counter
var _ACT_DELAY_ = 5; //Instrumental delay 

var DATA_PH      = []; //pH 
var DATA_PH_DIR1 = []; //1st derivative of pH
var DATA_PH_DIR2 = []; //2nd derivative of pH

//Graphs
var GRAPH_PH  = null; //pH
var GRAPH_PH1 = null; //1st derivative
var GRAPH_PH2 = null; //2nd derivative

//Autotitration flag
var AUTO_ACTIVE = false;

//Pause before pH measurement in ms (for manual titration)
_DELAY_BEFORE_PH_MEASUREMENT_MS_ = 2000;

_INST_DELAY_SEC_ = 15; // Delay to wait for mixing completion in seconds

//DEBUG -----------------------------
var _DEBUG_MODE_ = false;
var _DEBUG_VOLUME_COUNT_ = 0;
var _DEBUG_V2_ = 0.0;
var _DEBUG_V1_ = 3.0182E-01;
var _DEBUG_V0_ = 0.0;
//DEBUG -----------------------------

var TIMEOUT_ID = null;

//Parse and display volume and pH data obtained from the server
//Sample string to parse: Message = "OK 25.55 2.44"
function  MeasureVolPhResponse(Message)
{
   var VolPh = Message.split(" ",3);
   var Vol = parseFloat(VolPh[1]);
   var pH = parseFloat(VolPh[2]);
      
   //Display the result
   document.getElementById("vol").innerHTML = Vol.toFixed(2)+"&nbsp;"; 
   document.getElementById("ph").innerHTML  = pH.toFixed(2);
}

//Find absolute maximum
function GetMax(data_array)
{
   var p_max = [0.0,-1.0e30];
      
   for (var i = 0; i < data_array.length; i++)
   {                    
      var p = data_array[i];      
      var x  = p[0];
      var y  = p[1];
      
      if (y>=p_max[1])
      {
         p_max = p;         
      }      
   }
   
   return p_max;
}

//Calculate the 1st derivative
function GetDiv1(p0, p1)
{
   var x0  = p0[0];
   var y0  = p0[1];
   var x1  = p1[0];
   var y1  = p1[1];
   
   if (x1-x0 == 0.0 )
      { return null; }
   
   var x_ave = (x0+x1)/2.0;
   var Div1 = (y1-y0)/(x1-x0);
   return [x_ave,Div1];
}

function Update_data_ph(data_ph, Vol, pH)
{
   //Remove the first element if it is a zero place-holder
   if ( (data_ph[0][0] == 0.0) && (data_ph[0][1] == 0.0) )
   {                    
      data_ph.splice(0, 1);
   }

   if ( data_ph.length > 0 )
   {
      //Add new element only if the volume is changed, otherwise update it.
      var last_point = data_ph[data_ph.length - 1];
      VLast  = last_point[0];
      PhLast = last_point[1];

      if ( Vol == VLast)
      {
         data_ph[data_ph.length - 1][1] = pH;      
      }
      else
      {         
         data_ph.push([Vol, pH]);   
      }
   }
   else
   {
      data_ph.push([Vol, pH]);
   }   
}

function Update_data_ph_derivatives()
{   
   //Cannot calculate derivatives for 0 or 1 data point
   if ( DATA_PH.length < 2 )
   {
      return;
   }
   
   DATA_PH_DIR1 = [];
   
   if ( DATA_PH.length > 2 )
   {
      DATA_PH_DIR2= [];
   }
   
   for (var i = 1; i < DATA_PH.length; i++)
   {
      //Calculate 1st derivative
      var p2 = DATA_PH[i];
      var p1 = DATA_PH[i-1];
      var Div1_p12 = GetDiv1(p1, p2);
      DATA_PH_DIR1.push(Div1_p12);
      
      //Calculate 2nd derivative
      if ( i > 1 )
      {
         var p0 = DATA_PH[i-2];
         var Div1_p01  = GetDiv1(p0, p1);
         var Div2_p012 = GetDiv1(Div1_p01, Div1_p12);
         DATA_PH_DIR2.push(Div2_p012);
      }
   }
}

function Update_Complete_HTML_Table(data_ph)
{   
   var table = document.getElementById("phtable");
   table.innerHTML = "";
   MakeHTMLTableHeader(table);
      
   for (var i = 1; i < data_ph.length; i++)
   {
      var p = DATA_PH[i];
      var Vol = p[0];
      var pH = p[1];
      
      var last_row = table.rows[ table.rows.length - 1 ];      
      var row = table.insertRow(-1);
      var VolCell = row.insertCell(0);
      var pHCell  = row.insertCell(1);
      VolCell.innerHTML = Vol.toFixed(2);
      pHCell.innerHTML  = pH.toFixed(2);      
   }
}

function Update_HTML_table(data_ph, Vol, pH)
{
   //Add values to a table
   var table = document.getElementById("phtable");

   if ( data_ph.length > 0 )
   {
      //Add new element only if the volume is changed, otherwise update it.
      var last_row = table.rows[ table.rows.length - 1 ];      
      var VLast = parseFloat(last_row.cells[0].innerHTML);
      var PhLast = parseFloat(last_row.cells[1].innerHTML);
         
      if ( Vol == VLast )
      {        
         last_row.cells[1].innerHTML = pH;
      }
      else
      {
         var row = table.insertRow(-1);                
         var VolCell = row.insertCell(0);
         var pHCell  = row.insertCell(1);
         VolCell.innerHTML = Vol.toFixed(2);
         pHCell.innerHTML  = pH.toFixed(2);
      }
   }
   else
   {
      var row = table.insertRow(-1);                
      var VolCell = row.insertCell(0);
      var pHCell  = row.insertCell(1);
      VolCell.innerHTML = Vol.toFixed(2);
      pHCell.innerHTML  = pH.toFixed(2);
   }
}

function StoreData(Vol, pH)
{
   //Update data arrays
   Update_data_ph(DATA_PH, Vol, pH);
   //Calculate derivatives
   Update_data_ph_derivatives();
   //Update HTML table
   Update_HTML_table(DATA_PH, Vol, pH);
   //Redraw graphs   
   RedrawDygraph();   
}

//Receive data from the server using AJAX 
function GetPhV()
{
   InstrumentRequest(_PASSWORD_, _SESSION_ID_, _ACT_MEASURE_PH_V_, 0, MeasureVolPhResponse);        
   
   //These reading are used only in manual titration mode
   if ( !AUTO_ACTIVE )
   {
      TIMEOUT_ID = setTimeout('GetPhV()', _DELAY_BEFORE_PH_MEASUREMENT_MS_);
   }
}

//Action if user presses "Go"
function  GoResponse(Message)
{
   if ( (Message.toLowerCase().charAt(0)  == 'o') && (Message.toLowerCase().charAt(1) == 'k')  )
   {
      document.getElementById("statusbar").innerHTML = "Status: The solution has been dispensed successfully. Store pH and V values";
      document.getElementById("maxvol").disabled = true;
      document.getElementById("drain").disabled  = true;
      document.getElementById("go").disabled     = true;
      document.getElementById("store").disabled  = false;
      document.getElementById("auto").disabled   = true;
      document.getElementById("save").disabled   = false;
      document.getElementById("reset").disabled  = false;      
   }
   else
   {
      document.getElementById("statusbar").innerHTML = "Status: Cannot dispence the solution.";
   }
}

//Parse and display data obtained from the server if user pressed "Drain"
function  DrainResponse(Message)
{
   if ( (Message.toLowerCase().charAt(0)  == 'o') && (Message.toLowerCase().charAt(1) == 'k')  )
   {
      document.getElementById("statusbar").innerHTML = "Status: The solution has been drained successfully";
   }
   else
   {
      document.getElementById("statusbar").innerHTML = "Status: Cannot drain the solution.";
   }
      
   document.getElementById("dispstep").disabled = false;
   document.getElementById("drain").disabled  = false;
   document.getElementById("go").disabled     = false;       
   document.getElementById("auto").disabled   = false;
   document.getElementById("reset").disabled  = false;
   document.getElementById("dispstep").value = 1;
}

//Emulation of the Arduino board (used only if _DEBUG_MODE_ is set to true)
function EmulatedInstrumentRequest(Password, SessionID, ActionCode, ActionValue, ActionFunction)
{
   var Max_pH = 14.0;
   var EqVol = 15.0;
   var NoiseLlv = 0.8;
   var Curv = 2.0;
       
   switch(ActionCode)
   {          
       case _ACT_DRAIN_:
           ActionFunction("OK");
           document.getElementById("statusbar").innerHTML = "DEBUG: Drain requested action value:"+ActionValue.toString();
           break;
       case _ACT_GO_:
           _DEBUG_VOLUME_COUNT_ += ActionValue;
           ActionFunction("OK");
           break;
       case _ACT_MEASURE_PH_V_:
           document.getElementById("statusbar").innerHTML = "DEBUG: Emulated Titration";
           var Vol =(_DEBUG_V2_*_DEBUG_VOLUME_COUNT_+_DEBUG_V1_)*_DEBUG_VOLUME_COUNT_+_DEBUG_V0_;                
           var pH = (Max_pH/(1+Math.exp(-Curv*(Vol-EqVol)))+NoiseLlv*Math.random()).toFixed(2);
           var Str = Vol.toFixed(2).toString()+" "+pH.toString();                  
           var Message = "OK "+Vol.toString()+" "+pH.toString();   
           ActionFunction(Message);
           break;
       case _ACT_RESET_:
           _DEBUG_VOLUME_COUNT_ = 0;
           ActionFunction("OK");
           break;
       case _ACT_DELAY_:          
           ActionFunction("OK");
           break;                   
       default:
           return "";
   }
   
   return "";
}

//AJAX requests to the server
function InstrumentRequest(Password, SessionID, ActionCode, ActionValue, ActionFunction)
{   
   if (_DEBUG_MODE_)
   {
      EmulatedInstrumentRequest(Password, SessionID, ActionCode, ActionValue, ActionFunction);
   } 
   else
   {
      var myparams  = "hajax=1&nocache="+ Math.random() * 1000000;
          myparams += "&"+_CTR_KEY0_+"="+Password+"&"+_CTR_KEY1_+"="+SessionID+"&"+_CTR_KEY2_+"="+ActionCode+"&"+_CTR_KEY3_+"="+ActionValue;
   
      var request = new XMLHttpRequest();
          request.onreadystatechange = function()
          {
             if (this.readyState == 4)
             {
               if (this.status == 200)
               {
                  if (this.responseText != null)
                  {
                     ActionFunction(this.responseText);
                  }
               }
             }
          }        
      
      request.open("GET", _AJAX_FILE_+"?" + myparams, true);
      request.send(null);
   }   
} 

//Check if the number of dispension sets has been set correctly
function DispenseStepsCheck(DispenseSteps)
{ 
   if ( (DispenseSteps<1) || ((DispenseSteps>100)) )
   {                    
      window.alert("Dispension should be between 1 and 100 steps at a time");
      return false;
   }
   
   return true;
}   
//Action if user presses "Drain"
function ClickDrain()
{  
   document.getElementById("statusbar").innerHTML = "Status: Drain is requested. Wait...";
   
   var DispenseSteps = parseInt(document.getElementById("dispstep").value);
   
   if ( DispenseStepsCheck(DispenseSteps) )
   {
       document.getElementById("drain").disabled  = true;
       document.getElementById("go").disabled     = true;       
       document.getElementById("auto").disabled   = true;
       document.getElementById("reset").disabled  = true;
       document.getElementById("dispstep").disabled = true;
   
       InstrumentRequest(_PASSWORD_, _SESSION_ID_, _ACT_DRAIN_, DispenseSteps, DrainResponse);                
   }   
}

//Action if user presses "Go"
function ClickGo()
{
   var DispenseSteps = parseInt(document.getElementById("dispstep").value);
     
   if ( DispenseStepsCheck(DispenseSteps) )
   {
      document.getElementById("statusbar").innerHTML = "Status: Dispensing solution. Wait...";
      document.getElementById("dispstep").disabled = true;
      document.getElementById("maxvol").disabled = true;
      document.getElementById("drain").disabled  = true;
      document.getElementById("go").disabled     = true;
      document.getElementById("auto").disabled   = true;
      document.getElementById("store").disabled  = true; 
   
      InstrumentRequest(_PASSWORD_, _SESSION_ID_, _ACT_GO_, DispenseSteps, GoResponse);
   }   
}

//Resume manual control on titration
function ResumeManualControl()
{
   document.getElementById("dispstep").disabled = false;
   document.getElementById("maxvol").disabled = false;
   document.getElementById("drain").disabled  = false;
   document.getElementById("go").disabled     = false;
   document.getElementById("store").disabled  = false;      
   document.getElementById("auto").disabled   = false;      
   document.getElementById("save").disabled   = false;
   document.getElementById("reset").disabled  = false;         
}

function  InstDelayResponse(Message)
{
   if ( (Message.toLowerCase().charAt(0)  == 'o') && (Message.toLowerCase().charAt(1) == 'k')  )
   {
      document.getElementById("statusbar").innerHTML = "Status: Instumental delay has been completed... (in auto mode)";      
   }
   else
   {
      document.getElementById("statusbar").innerHTML = "Status: Cannot delay execution... (in auto mode)";
   }
   
   GetAutoPhV();   
}

//Response after automatic dispension
function  GoAutoResponse(Message)
{
   if ( (Message.toLowerCase().charAt(0)  == 'o') && (Message.toLowerCase().charAt(1) == 'k')  )
   {
      document.getElementById("statusbar").innerHTML = "Status: The solution has been dispensed successfully. (in auto mode)";
      //Delay to wait for mixing completion
      InstrumentRequest(_PASSWORD_, _SESSION_ID_, _ACT_DELAY_, _INST_DELAY_SEC_, InstDelayResponse);
      document.getElementById("statusbar").innerHTML = "Status: Instrumental delay has been requested... (in auto mode)";
   }
   else
   {
      document.getElementById("statusbar").innerHTML = "Status: Cannot dispence the solution. (in auto mode)";
   }   
}

//Find the equivalence point 
function  GetEqPoint(DATA_PH, DATA_PH_DIR1, DATA_PH_DIR2)
{   
   var EqPnt = GetMax(DATA_PH_DIR1);
   return EqPnt
}

function AutotitrationCompletion(Message)
{
   if ( !AUTO_ACTIVE )
      return;

   AUTO_ACTIVE = false;       
   
   //Determine the equivalence point
   var eqPnt = GetEqPoint(DATA_PH, DATA_PH_DIR1, DATA_PH_DIR2);   
   var EqString = "Equivalence point: <b>"+eqPnt[0].toFixed(2)+"</b>, mL</b>";
   document.getElementById("statusbareqp").innerHTML = Message+"<br>"+EqString;

   document.getElementById("auto").value   = "Auto";
   ResumeManualControl();
   
   //Resume pH measurements in manual model 
   GetPhV();
}

function  MeasureAutoVolPhResponse(Message)
{
   if( !AUTO_ACTIVE )
   {
      return;
   }
   
   var VolPh = Message.split(" ",3);   

   var Vol = parseFloat(VolPh[1]);
   var pH = parseFloat(VolPh[2]);
      
   //Display the result
   document.getElementById("vol").innerHTML = Vol.toFixed(2)+"&nbsp;"; 
   document.getElementById("ph").innerHTML  = pH.toFixed(2);
   
   var MaximalVolume = parseInt(document.getElementById("maxvol").value);
   
   //Store the result
   StoreData(Vol, pH);
   
   //Automatic titration has been completed
   if ( Vol >= MaximalVolume )
   {      
       AutotitrationCompletion("Autotitration completed.");       
   }
   else
   {
      //Request dispension
      var DispenseSteps = 1;      
      InstrumentRequest(_PASSWORD_, _SESSION_ID_, _ACT_GO_, DispenseSteps, GoAutoResponse);
   }
}

//Main autitration loop
function GetAutoPhV()
{
   if ( AUTO_ACTIVE )
   {
      InstrumentRequest(_PASSWORD_, _SESSION_ID_, _ACT_MEASURE_PH_V_, 0, MeasureAutoVolPhResponse);              
   }
}

//Actions if user requested automatic titration "Auto"
function ClickAuto()
{
   //if autotitration has been already started.
   if( AUTO_ACTIVE )
   { 
      AutotitrationCompletion("Status: autotitration has been terminated.");       	
      return;
   }
   
   var DispenseSteps = parseInt(document.getElementById("dispstep").value);
   
   if ( !DispenseStepsCheck(DispenseStepsCheck) )
   {
      return;
   }
   
   if ( !confirm("Would you like to start autotitration?") )
   {
       return;
   }
   
   
   clearTimeout(TIMEOUT_ID); // Stop automatic measurements   
   document.getElementById("statusbareqp").innerHTML  = "";   
   AUTO_ACTIVE = true;
   document.getElementById("auto").value   = "Stop";
   document.getElementById("statusbar").innerHTML = "Status: autotitration has been initiated.";
   //User cannot control titration in the autoamtic mode
   document.getElementById("dispstep").disabled = true;
   document.getElementById("maxvol").disabled = true;
   document.getElementById("drain").disabled  = true;
   document.getElementById("go").disabled     = true;
   document.getElementById("store").disabled  = true; 
   document.getElementById("auto").disabled   = false;
   document.getElementById("save").disabled   = false;
   document.getElementById("reset").disabled  = true;
   
   //Start main autotitration loop
   GetAutoPhV();
}

//Record current value of pH
function ClickStore()
{
   var Vol = parseFloat(document.getElementById("vol").innerHTML);
   var pH = parseFloat(document.getElementById("ph").innerHTML);
   StoreData(Vol, pH);
   document.getElementById("go").disabled = false;
   document.getElementById("dispstep").value = 1;
   document.getElementById("dispstep").disabled = false;
   document.getElementById("statusbar").innerHTML = "Status: pH and volume have been stored. Continue titration.";
}

//Save pH data to CSV file
function ClickSave()
{
   var csvContentArray = [];                                                
   csvContentArray.push("data:text/csv;charset=utf-8,");
   csvContentArray.push("V mL,pH");
   DATA_PH.forEach(function(Array_Elem, index)
                   {
                       csvContentArray.push(Array_Elem.join(","));
                   });
   
   var csvContent = csvContentArray.join("\n");
   var encodedUri = encodeURI(csvContent);    
   
   //Create hyperkink using DOM
   var link = document.createElement('a');
   link.setAttribute('href', encodedUri);
   link.setAttribute('download', 'titration_data.csv');
   link.id = "mysavel";
   document.body.appendChild(link);
   //Imitate click on the link
   link = document.getElementById('mysavel');
   link.click();
}

//Construct header of the table to store pH values
function MakeHTMLTableHeader(table)
{   
   table.innerHTML="<thead><tr><th>Volume, mL</th><th>pH</th></thead><tbody></tbody>";
}

function  ResetResponse(Message)
{
   if ( (Message.toLowerCase().charAt(0)  == 'o') && (Message.toLowerCase().charAt(1) == 'k')  )
   {
      document.getElementById("statusbar").innerHTML = "Status: Reset completed.";
      document.getElementById("save").disabled   = true;
      document.getElementById("store").disabled  = true; 
   }
   else
   {
      document.getElementById("statusbar").innerHTML = "Status: Reset error.";
      document.getElementById("save").disabled   = false;
      document.getElementById("store").disabled  = false;       
   }
   
   document.getElementById("dispstep").value = 1;
   document.getElementById("dispstep").disabled = false;
   document.getElementById("maxvol").disabled = false;
   document.getElementById("drain").disabled  = false;
   document.getElementById("go").disabled     = false;   
   document.getElementById("auto").disabled   = false;   
   document.getElementById("reset").disabled  = false;   
}

//Reset pH data and derivatives of pH
function ClickReset()
{
   //document.getElementById("ctr1").value  = ACTION_RESET;
   if ( !confirm("Do you want to delete all data?") )
   {
      return;
   }
   
   var table = document.getElementById("phtable");
   while ( table.rows.length > 0 )
   {
      table.deleteRow(0);
   }

   MakeHTMLTableHeader(table);
   DATA_PH = [];
   DATA_PH.push([0.0, 0.0]);

   DATA_PH_DIR1 = [];
   DATA_PH_DIR1.push([0.0, 0.0]);
   DATA_PH_DIR2 = [];
   DATA_PH_DIR2.push([0.0, 0.0]);
   RedrawDygraph();
       
   //Disable titration options during resetting   
   document.getElementById("statusbar").innerHTML = "Status: Reset requested. Wait...";
   document.getElementById("statusbareqp").innerHTML  = "";
   document.getElementById("drain").disabled  = true;
   document.getElementById("go").disabled     = true;
   document.getElementById("store").disabled  = true; 
   document.getElementById("auto").disabled   = true;
   document.getElementById("save").disabled   = false;
   document.getElementById("reset").disabled  = true;   
   AUTO_ACTIVE = false;
   
   InstrumentRequest(_PASSWORD_, _SESSION_ID_, _ACT_RESET_, 0, ResetResponse);
}

//Draw pH and derivatives
function RedrawDygraph()
{
   GRAPH_PH  = new Dygraph(document.getElementById("graphdiv"),DATA_PH,{xlabel:'Volume, mL',ylabel:'pH',legend:'always',labelsDivStyles:{'textAlign': 'right'},valueRange: [0, 14], yRangePad: 35, includeZero: true });
   GRAPH_PH1 = new Dygraph(document.getElementById("graphdiv1"),DATA_PH_DIR1,{xlabel:'Volume, mL',ylabel:'1st Derivative of pH',legend:'always',labelsDivStyles: {'textAlign': 'right'}});
   GRAPH_PH2 = new Dygraph(document.getElementById("graphdiv2"),DATA_PH_DIR2,{xlabel:'Volume, mL',ylabel:'2nd Derivative of pH',legend:'always',labelsDivStyles: {'textAlign': 'right'}});
}

//Construct graphic user interface using DOM model
function Run(pPassword, pSessionId)
{
   _PASSWORD_ = pPassword;
   _SESSION_ID_ = pSessionId;

   document.title = "MU Lab Control Server";
   var elemDiv = document.createElement('div');
   elemDiv.className = "header";
   elemDiv.innerHTML = "<h1>MU Lab Server</h1>";      
   document.body.appendChild(elemDiv);
   
   elemDiv = document.createElement('div');
   elemDiv.className = "header";
   
   var form = document.createElement('form');
   form.name = "phform";
   form.id = "phform";
   form.action = "control.htm";
   form.method="GET";   
   form.innerHTML = "<h2>Control</h2>";
   
   var elemDiv2 = document.createElement('div');
   elemDiv2.className = "divform";
   
   var elemSpan = document.createElement('span');
   elemSpan.className = "lbl";
   elemSpan.innerHTML = "Dispense steps:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
   elemDiv2.appendChild(elemSpan);

   var elemInput = document.createElement('input');
   elemInput.className = "dispstep";
   elemInput.type  = "text";
   elemInput.name  = "DispStep";
   elemInput.id    = "dispstep";
   elemInput.value = "1";
   elemDiv2.appendChild(elemInput);
   
   var elemBr = document.createElement('br');
   elemDiv2.appendChild(elemBr);
       
   elemSpan = document.createElement('span');
   elemSpan.className = "lbl";
   elemSpan.innerHTML = "Max. volume &nbsp;mL:&nbsp;&nbsp;";   
   elemDiv2.appendChild(elemSpan);

   elemSpan = document.createElement('span');
   elemSpan.innerHTML = '<input class="maxvol" type="text" name="maxvol" id="maxvol" value="50.00" ><br>';   
   elemDiv2.appendChild(elemSpan);
       
   elemSpan = document.createElement('span');   
   elemSpan.innerHTML = '<input class="btn" id="drain" onclick="ClickDrain()" value="Drain" type="button" >';
   elemDiv2.appendChild(elemSpan);
    
   elemSpan = document.createElement('span');   
   elemSpan.innerHTML = '<input class="btn" id="go" onclick="ClickGo()" value=" Go " type="button" >';
   elemDiv2.appendChild(elemSpan);
      
   elemSpan = document.createElement('span');   
   elemSpan.innerHTML = '<input class="btn" id="store" onclick="ClickStore()" value="Store" type="button" disabled>';
   elemDiv2.appendChild(elemSpan);

   elemSpan = document.createElement('span');   
   elemSpan.innerHTML = '<input class="btn" id="auto" onclick="ClickAuto()" value="Auto" type="button" >';
   elemDiv2.appendChild(elemSpan);

   elemSpan = document.createElement('span');   
   elemSpan.innerHTML = '<input class="btn" id="save" onclick="ClickSave()" value="Save" type="button" disabled>';
   elemDiv2.appendChild(elemSpan);
   
   elemSpan = document.createElement('span');           
   elemSpan.innerHTML = '<input class="btn" id="reset" onclick="ClickReset()" value="Reset" type="button" >';
   elemDiv2.appendChild(elemSpan);
   
   form.appendChild(elemDiv2);
   
   elemDiv.appendChild(form);
   document.body.appendChild(elemDiv);
   
   elemDiv = document.createElement('div');
   elemDiv.className = "header";
   elemDiv.id = "statusbar";    
   elemDiv.innerHTML = 'Status: Ready.<br>';
   document.body.appendChild(elemDiv);
   
   elemDiv = document.createElement('div');
   elemDiv.className = "header";
   elemDiv.id = "statusbareqp";    
   elemDiv.innerHTML = '<br>';
   document.body.appendChild(elemDiv);
   
   elemDiv = document.createElement('div');
   elemDiv.className = "header";
   elemDiv.innerHTML = "<h2>Measurements</h2>";
   
   elemSpan = document.createElement('span');
   elemSpan.innerHTML = '<span class="lbl">V, mL:&nbsp;';
   elemDiv.appendChild(elemSpan);
   
   elemSpan = document.createElement('span');
   elemSpan.className = "lblvalue";
   elemSpan.id = "vol";
   elemSpan.innerHTML = '0.00&nbsp;&nbsp;&nbsp;&nbsp;';
   elemDiv.appendChild(elemSpan);
   
   elemSpan = document.createElement('span');
   elemSpan.className = "lbl";
   elemSpan.innerHTML = 'pH:&nbsp;';
   elemDiv.appendChild(elemSpan);
   
   elemSpan = document.createElement('span');
   elemSpan.className = "lblvalue";
   elemSpan.id = "ph";
   elemSpan.innerHTML = '0.00';
   elemDiv.appendChild(elemSpan);
   
   elemSpan = document.createElement('span');   
   elemSpan.innerHTML = '<br>';
   elemDiv.appendChild(elemSpan);
   
   document.body.appendChild(elemDiv);
   
   elemDiv = document.createElement('div');
   elemDiv.className = "header";
   elemDiv.innerHTML = '<div id="graphdiv" class="graphdiv"></div>';
   document.body.appendChild(elemDiv);
   
   elemDiv = document.createElement('div');
   elemDiv.className = "header";
   elemDiv.innerHTML = '<div id="graphdiv1" class="graphdiv"></div>';
   document.body.appendChild(elemDiv);
   
   elemDiv = document.createElement('div');
   elemDiv.className = "header";
   elemDiv.innerHTML = '<div id="graphdiv2" class="graphdiv"></div>';
   document.body.appendChild(elemDiv);
   
   elemDiv = document.createElement('div');
   elemDiv.className = "header";
   elemDiv.innerHTML = '<div class="datagrid"><table id="phtable"></table></div>';
   document.body.appendChild(elemDiv);
      
   elemDiv = document.createElement('div');
   elemDiv.innerHTML = '<div class="footer">Copyright &copy; 2013-15 The Kosenkov Lab &#64; Monmouth University<br></div>';
   document.body.appendChild(elemDiv);   

   //Reset pH data
   DATA_PH.push([0.0, 0.0]);
   DATA_PH_DIR1.push([0.0, 0.0]);
   DATA_PH_DIR2.push([0.0, 0.0]);
   
   //Draw empty pH graphs and table
   RedrawDygraph();
   var table = document.getElementById("phtable");
   MakeHTMLTableHeader(table);
   
   //Start automatic pH measurement
   GetPhV();                     
}