/**
 * JavaScript to provide internet interface for the lab equipment
 *
 * Version 7.7.0
 * Dmytro Kosenkov and Nicole Famularo, Monmouth University
 * 
 * May 28, 2015
 * 
 **/

function SetTimeStamp()
{
   var d = new Date();        
   //Time is used as session ID 
   document.getElementById("ctrl1").value = d.getTime();        
   //Date is used for authorization
   document.getElementById("ctrl2").value = d.getDate();
}

function Run()
{
   document.title = "MU Lab Control Server";
   var elemDiv = document.createElement('div');
   elemDiv.className = "header";
   elemDiv.innerHTML = "<h1>MU Lab Server</h1>";      
   document.body.appendChild(elemDiv);

   elemDiv = document.createElement('div');
   elemDiv.className = "header";
   
   var form = document.createElement('form');
   form.name = "welcome";
   form.action = "control.htm";
   form.method="GET";
   form.onsubmit=SetTimeStamp;
   form.innerHTML = "<h2>Passcode</h2>";
      
   var elemDiv2 = document.createElement('div');
   elemDiv2.className = "divform";
      
   var elemInput = document.createElement('input');
   elemInput.type  = "password";
   elemInput.name  = "Ctr0";
   elemInput.id    = "ctrl0";
   elemInput.value = "123123";
   elemDiv2.appendChild(elemInput);
   
   var elemBr = document.createElement('br');
   elemDiv2.appendChild(elemBr);
   
   elemInput = document.createElement("input");
   elemInput.type  = "hidden";
   elemInput.name  = "Ctr1";
   elemInput.id    = "ctrl1";   
   elemDiv2.appendChild(elemInput);
   
   elemInput = document.createElement("input");
   elemInput.type  = "hidden";
   elemInput.name  = "Ctr2";
   elemInput.id    = "ctrl2";
   elemDiv2.appendChild(elemInput);
   
   elemBr = document.createElement('br');
   elemDiv2.appendChild(elemBr);
   
   elemInput = document.createElement("input");
   elemInput.type  = "submit";   
   elemInput.value = "Submit";   
   elemDiv2.appendChild(elemInput);
  
   form.appendChild(elemDiv2);
   
   elemDiv.appendChild(form);
   document.body.appendChild(elemDiv);
   
   var elemDiv = document.createElement('div');
   elemDiv.innerHTML = '<div class="footer">Copyright &copy; 2013-15 The Kosenkov Lab &#64; Monmouth University<br></div>';
   document.body.appendChild(elemDiv);
   
   SetTimeStamp();
}
