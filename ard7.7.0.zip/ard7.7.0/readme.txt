Directory Content and Description
ardX.X.0
\arduino
		\phcalib\phcalib.ino � Arduino pH calibration script
		\volcalib\volcalib.ino � Arduino volumetric calibration script
		\webph\webph.ino � Arduino network integration script
\external\ard � This directory and its content should be placed on the auxiliary webserver ( e.g. http://myserver.myuniversity.edu/~myname/ard )
			\css
				\in.css � style sheets for the login webpage (index.htm)
				\ctr.css� style sheets for the main control webpage (control.htm)
			\java
				\in.js  � JavaScript for the login webpage (index.htm)
				\ctr.js� JavaScript for the main control webpage (control.htm). All data processing (calculation of derivatives, pH plots etc.) happens in this script. The script can be also used without the Arduino board to emulate pH measurements.


The network integration script (webph.ino) automatically uses two external JavaScript libraries: 
http://code.jquery.com/jquery-1.4.4rc2.js (general purpose AJAX functions)
http://dygraphs.com/dygraph-combined.js (Plotting graphs)


